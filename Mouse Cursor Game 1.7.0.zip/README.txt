Copyright (C) 2018-2020 Kygekraqmak

Any redistribution of this game is not under warranty by its developers!